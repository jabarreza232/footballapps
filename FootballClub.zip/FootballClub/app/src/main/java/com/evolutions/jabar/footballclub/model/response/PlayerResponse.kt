package com.evolutions.jabar.footballclub.model.response

import com.evolutions.jabar.footballclub.model.player.Players

data class PlayerResponse (
     val player:List<Players>
)