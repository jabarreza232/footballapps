package com.evolutions.jabar.footballclub.fragment.team

import android.annotation.SuppressLint
import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v4.widget.SwipeRefreshLayout
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.text.Editable
import android.text.TextWatcher
import android.view.*
import android.widget.*

import com.evolutions.jabar.footballclub.R
import com.evolutions.jabar.footballclub.R.array.league
import com.evolutions.jabar.footballclub.activity.detail.team.TeamDetailActivity
import com.evolutions.jabar.footballclub.api.ApiRespository
import com.evolutions.jabar.footballclub.model.team.Teams
import com.evolutions.jabar.footballclub.view.invisible
import com.evolutions.jabar.footballclub.view.visible
import com.google.gson.Gson
import com.mancj.materialsearchbar.MaterialSearchBar
import kotlinx.android.synthetic.main.fragment_team.*
import kotlinx.android.synthetic.main.fragment_team.view.*
import org.jetbrains.anko.*
import org.jetbrains.anko.recyclerview.v7.recyclerView

import org.jetbrains.anko.support.v4.onRefresh
import org.jetbrains.anko.support.v4.swipeRefreshLayout


class TeamFragment : Fragment(),TeamView {

    private var teams: MutableList<Teams> = mutableListOf()

    private lateinit var presenter: TeamPresenter
    private lateinit var adapter: TeamAdapter
    /*
        private lateinit var spinner: Spinner
        private lateinit var listEvent: RecyclerView
        private lateinit var progressBar: ProgressBar
        private lateinit var swipeRefresh: SwipeRefreshLayout
    */
    private lateinit var leagueName: String
    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        val spinnerItems = resources.getStringArray(league)
        val spinnerAdapter = ArrayAdapter(requireContext(),android.R.layout.simple_spinner_dropdown_item,spinnerItems)
        spinner.adapter= spinnerAdapter
        adapter = TeamAdapter(teams){
            requireContext().startActivity<TeamDetailActivity>("id" to "${it.teamId}")
        }
        list_team.adapter = adapter
        val request = ApiRespository()
        val gson = Gson()
        presenter = TeamPresenter(this, request,gson)

        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {

            override fun onItemSelected(parent: AdapterView<*>, view: View, position: Int, id: Long) {
                leagueName = spinner.selectedItem.toString()
                presenter.getTeamList(leagueName)

            }


            override fun onNothingSelected(parent: AdapterView<*>) {}

        }
        swipeRefresh.onRefresh {
            presenter.getTeamList(leagueName)
        }

searchBarTeam.addTextChangeListener(object:TextWatcher{
    override fun afterTextChanged(p0: Editable?) {

    }

    override fun beforeTextChanged(charSequence: CharSequence, p1: Int, p2: Int, p3: Int) {
        presenter.getTeamList(leagueName)

    }

    override fun onTextChanged(charSequence: CharSequence, p1: Int, p2: Int, p3: Int) {
        val search:String?= charSequence.toString()
        presenter.searchTeam(search)

    }

})



    }


    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?) :View? {
        val view:View
        view = inflater.inflate(R.layout.fragment_team,container,false)
        return view
    }

    /*
    @SuppressLint("ResourceAsColor")
    override fun createView(ui:AnkoContext<Context>):View= with(ui){
        linearLayout{
            lparams(width= matchParent,height = wrapContent)
            orientation = LinearLayout.VERTICAL
            topPadding=dip(16)
            leftPadding = dip(16)
            rightPadding = dip(16)


            spinner = spinner()

            swipeRefresh = swipeRefreshLayout{
                setColorSchemeColors(android.support.design.R.attr.colorAccent,
                        android.R.color.holo_green_light,
                        android.R.color.holo_orange_light,
                        android.R.color.holo_red_light
                )
                relativeLayout {
                    lparams(width= matchParent, height = wrapContent)
                    listEvent = recyclerView{
                        lparams(width= matchParent,height = wrapContent)
                        layoutManager= LinearLayoutManager(ctx)
                    }
                    progressBar=progressBar{

                    }.lparams{
                        centerHorizontally()
                    }
                }

            }

        }
    }

*/
    override fun showLoading() {
        progressBar.visible()
    }

    override fun hideLoading() {
        progressBar.invisible()
    }

    override fun showTeamList(data: List<Teams>?) {
        swipeRefresh.isRefreshing= false
        teams.clear()
      if (data !=null) {
    teams.addAll(data)

  }
        adapter.notifyDataSetChanged()
    }


}
