package com.evolutions.jabar.footballclub.fragment.event

import android.os.Bundle
import android.support.v4.app.Fragment
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import com.evolutions.jabar.footballclub.R
import com.evolutions.jabar.footballclub.activity.detail.event.DetailEvents
import com.evolutions.jabar.footballclub.api.ApiRespository
import com.evolutions.jabar.footballclub.fragment.event.adapter.NextMatchAdapter
import com.evolutions.jabar.footballclub.fragment.event.presenter.NextMatchPresenter
import com.evolutions.jabar.footballclub.fragment.event.view.NextmatchView
import com.evolutions.jabar.footballclub.model.event.Event
import com.evolutions.jabar.footballclub.view.invisible
import com.evolutions.jabar.footballclub.view.visible
import com.google.gson.Gson
import kotlinx.android.synthetic.main.fragment_nextmatch.*
import org.jetbrains.anko.startActivity
import org.jetbrains.anko.support.v4.onRefresh


class NextmatchFragment : Fragment(), NextmatchView {

    /*
        private lateinit var listTeam: RecyclerView
        private lateinit var progressBar: ProgressBar
        private lateinit var swipeRefresh: SwipeRefreshLayout
      */

    private var events: MutableList<Event> = mutableListOf()
    private lateinit var presenter: NextMatchPresenter
    private lateinit var adapter: NextMatchAdapter
    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        val league = arrayOf("4328", "4329", "4330", "4331", "4332", "4334", "4335")
        val spinnerItems = resources.getStringArray(R.array.league)
        val spinnerAdapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_dropdown_item, spinnerItems)
        val spinnerPosition = spinnerAdapter.getPosition("English Premier League")
        spinnerNext.adapter = spinnerAdapter
        adapter = NextMatchAdapter(requireContext(), events) {
            requireContext().startActivity<DetailEvents>("id" to it.eventId)
        }
        list_next_match.adapter = adapter
        spinnerNext.setSelection(spinnerPosition)
        val request = ApiRespository()
        val gson = Gson()
        presenter = NextMatchPresenter(this, request, gson)
        presenter.getNextMatchList(league[0])
        swipeRefreshNext.onRefresh {
            presenter.getNextMatchList(league[0])
        }
        searchBarNext.setHint("Search Match...")
        searchBarNext.addTextChangeListener(object : TextWatcher {
            override fun afterTextChanged(p: Editable?) {
                val search: String? = p.toString()
                presenter.searchEvent(search)
            }

            override fun beforeTextChanged(charSequence: CharSequence?, p1: Int, p2: Int, p3: Int) {
                presenter.getNextMatchList(league[0])
            }

            override fun onTextChanged(charSequence: CharSequence?, p1: Int, p2: Int, p3: Int) {
                val search: String? = charSequence.toString()
                presenter.searchEvent(search)

            }

        })
        spinnerNext.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(p0: AdapterView<*>?) {

            }

            override fun onItemSelected(p0: AdapterView<*>?, p1: View?, pos: Int, p3: Long) {
                presenter.getNextMatchList(league[pos])
            }

        }

    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_nextmatch, container, false)

    }

    /*
        override fun createView(ui: AnkoContext<Context>): View = with(ui){
            linearLayout {
                lparams(width = matchParent, height = wrapContent)
                orientation = LinearLayout.VERTICAL
                topPadding = dip(16)
                leftPadding = dip(16)
                rightPadding = dip(16)

                /*spinner = spinner() */

                swipeRefresh = swipeRefreshLayout {
                    setColorSchemeResources(
                            android.R.color.holo_green_light,
                            android.R.color.holo_orange_light,
                            android.R.color.holo_red_light
                    )
                    relativeLayout {
                        lparams(width = matchParent, height = wrapContent)
                        listTeam = recyclerView {
                            lparams(width = matchParent, height = wrapContent)
                            layoutManager = LinearLayoutManager(ctx)
                        }
                        progressBar = progressBar {
                        }.lparams {
                            centerHorizontally()
                        }
                    }

                }
            }

        }
      */
    override fun showLoading() {
        progressBarNext.visible()
    }

    override fun hideLoading() {
        progressBarNext.invisible()
    }

    override fun showNextMatchList(data: List<Event>?) {
        swipeRefreshNext.isRefreshing = false
        events.clear()
        if (data != null) {
            events.addAll(data)
        }
        adapter.notifyDataSetChanged()
    }
}

