package com.evolutions.jabar.footballclub.activity.main

import com.evolutions.jabar.footballclub.model.player.Players

interface PlayerView{
    fun showLoading()
    fun hideLoading()
    fun showPlayers(data:List<Players>)

}