package com.evolutions.jabar.footballclub.model.response

import com.evolutions.jabar.footballclub.model.event.Event
import com.evolutions.jabar.footballclub.model.team.Teams

data class TeamEventResponse(
        val events: List<Event>,
        val teams: List<Teams>,
        val event: List<Event>
)