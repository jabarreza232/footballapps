package com.evolutions.jabar.footballclub.fragment.event.presenter

import com.evolutions.jabar.footballclub.CoroutineContextProvider
import com.evolutions.jabar.footballclub.api.ApiRespository
import com.evolutions.jabar.footballclub.api.TheSportDbApi
import com.evolutions.jabar.footballclub.fragment.event.view.NextmatchView
import com.evolutions.jabar.footballclub.model.response.TeamEventResponse
import com.google.gson.Gson
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import org.jetbrains.anko.doAsync
import org.jetbrains.anko.uiThread

class NextMatchPresenter(private val view: NextmatchView,
                         private val apiRespository: ApiRespository,
                         private val gson: Gson ,private val context:CoroutineContextProvider = CoroutineContextProvider()) {
    fun getNextMatchList(league: String?) {
        view.showLoading()
        GlobalScope.launch(context.main) {
            val data = gson.fromJson(apiRespository.doRequest(TheSportDbApi.getNextMatch(league)).await(),
                    TeamEventResponse::class.java)
            if (data != null) {
                view.hideLoading()
                view.showNextMatchList(data.event)
            }
        }

    }

    fun searchEvent(search: String?) {
        view.showLoading()
        GlobalScope.launch(context.main) {
            val data = gson.fromJson(apiRespository.doRequest(TheSportDbApi.searchEvent(search)).await(),
                    TeamEventResponse::class.java)
            view.hideLoading()
            view.showNextMatchList(data.event)
        }
    }
}