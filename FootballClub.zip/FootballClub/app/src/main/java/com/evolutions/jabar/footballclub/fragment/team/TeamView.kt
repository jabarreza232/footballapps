package com.evolutions.jabar.footballclub.fragment.team

import com.evolutions.jabar.footballclub.model.team.Teams

interface TeamView{
    fun showLoading()
    fun hideLoading()
    fun showTeamList(data: List<Teams>?)
}