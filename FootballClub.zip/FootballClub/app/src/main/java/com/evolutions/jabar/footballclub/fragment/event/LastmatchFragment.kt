package com.evolutions.jabar.footballclub.fragment.event

import android.os.Bundle
import android.support.v4.app.Fragment
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import com.evolutions.jabar.footballclub.R
import com.evolutions.jabar.footballclub.activity.detail.event.DetailEvents
import com.evolutions.jabar.footballclub.api.ApiRespository
import com.evolutions.jabar.footballclub.fragment.event.adapter.LastMatchAdapter
import com.evolutions.jabar.footballclub.fragment.event.presenter.LastMatchPresenter
import com.evolutions.jabar.footballclub.fragment.event.view.LastMatchView
import com.evolutions.jabar.footballclub.model.event.Event
import com.evolutions.jabar.footballclub.view.invisible
import com.evolutions.jabar.footballclub.view.visible
import com.google.gson.Gson
import kotlinx.android.synthetic.main.fragment_lastmatch.*
import org.jetbrains.anko.startActivity
import org.jetbrains.anko.support.v4.onRefresh

class LastmatchFragment : Fragment(), LastMatchView {

    private var events: MutableList<Event> = mutableListOf()
    private lateinit var presenter: LastMatchPresenter
    private lateinit var adapter: LastMatchAdapter


    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)

        adapter = LastMatchAdapter(requireContext(), events) {
            requireContext().startActivity<DetailEvents>("id" to it.eventId)
        }
        list_last_match.adapter = adapter

        val league = arrayOf("4328", "4329", "4330", "4331", "4332", "4334", "4335")
        val spinnerItems = resources.getStringArray(R.array.league)
        val spinnerAdapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_dropdown_item, spinnerItems)
        val spinnerPosition = spinnerAdapter.getPosition("English Premier League")

        spinnerLast.adapter = spinnerAdapter
        spinnerLast.setSelection(spinnerPosition)
        val request = ApiRespository()
        val gson = Gson()
        presenter = LastMatchPresenter(this, request, gson)
        presenter.getEventList(league[0])

        swipeRefreshLast.onRefresh {
            presenter.getEventList(league[0])
        }


        searchBarLast.setHint("Search Match...")

        searchBarLast.addTextChangeListener(object : TextWatcher {

            override fun afterTextChanged(editable: Editable?) {
                val search: String? = editable.toString();
                presenter.searchEvent(search)
            }

            override fun beforeTextChanged(charSequence: CharSequence?, i: Int, i1: Int, i2: Int) {

            }

            override fun onTextChanged(charSequence: CharSequence?, i: Int, i1: Int, i2: Int) {
                val search: String? = charSequence.toString()
                presenter.searchEvent(search)
            }

        })
        spinnerLast.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(p0: AdapterView<*>?) {
            }

            override fun onItemSelected(p0: AdapterView<*>?, p1: View?, pos: Int, p3: Long) {
                presenter.getEventList(league[pos])
            }
        }
    }


    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment


        return inflater.inflate(R.layout.fragment_lastmatch, container, false)


    }

    /*



    override fun createView(ui: AnkoContext<Context>): View = with(ui){

        linearLayout {

            lparams(width = matchParent, height = wrapContent)
            orientation = LinearLayout.VERTICAL
            topPadding = dip(16)
            leftPadding = dip(16)
            rightPadding = dip(16)
/*            spinner = spinner()*/
              swipeRefresh = swipeRefreshLayout {
                setColorSchemeResources(
                        android.R.color.holo_green_light,
                        android.R.color.holo_orange_light,
                        android.R.color.holo_red_light
                )
                relativeLayout {
                    lparams(width = matchParent, height = wrapContent)
                    listTeam = recyclerView {
                        id = R.id.list_event
                        lparams(width = matchParent, height = wrapContent)
                        layoutManager = LinearLayoutManager(ctx)
                    }
                    progressBar = progressBar {
                    }.lparams {
                        centerHorizontally()
                    }
                }

            }

        }
    }
*/
    override fun showLoading() {
        progressBarLast.visible()

    }

    override fun hideLoading() {
        progressBarLast.invisible()

    }

    override fun showLastMatchList(data: List<Event>?) {
        swipeRefreshLast.isRefreshing = false
        events.clear()
        if (data != null) {
            events.addAll(data)
        }
        adapter.notifyDataSetChanged()

    }

}